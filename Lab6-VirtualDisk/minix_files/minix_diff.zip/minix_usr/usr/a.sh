NAME="diskfile.bin"
SIZE=11100

./main $NAME $SIZE

